# BACKROOMS — Hors-Limites (version installable, hors ligne)

Jeu d'horreur 3D qui s'installe sur ton téléphone comme une application et qui marche **sans internet** (dans l'avion, par exemple) une fois installé.

## Contenu du dossier

| Fichier | Rôle |
|---|---|
| `index.html` | Le jeu |
| `manifest.webmanifest` | Fait de la page une application (nom, icône, plein écran, mode paysage) |
| `sw.js` | Garde le jeu en mémoire pour jouer sans connexion |
| `icon-192.png`, `icon-512.png` | L'icône de l'application |

## Mettre le jeu en ligne (une seule fois, gratuit) avec GitHub Pages

1. Va sur github.com, connecte-toi, clique sur **New** pour créer un dépôt (par exemple `backrooms`), en **Public**.
2. Clique sur **Add file** puis **Upload files**, et glisse-y **les 5 fichiers** du dossier (pas le dossier lui-même, ses fichiers). Valide avec **Commit changes**.
3. Va dans **Settings**, puis **Pages**. Dans « Branch », choisis **main** et le dossier **/ (root)**, puis **Save**.
4. Attends 1 à 2 minutes. L'adresse apparaît en haut de la page Pages : `https://ton-pseudo.github.io/backrooms/`.

## Installer sur ton téléphone

Ouvre l'adresse ci-dessus **avec internet** (c'est important pour la première fois), et laisse la page se charger jusqu'au menu du jeu.

- **Android (Chrome)** : menu **⋮**, puis **Installer l'application** (ou **Ajouter à l'écran d'accueil**).
- **iPhone (Safari)** : bouton **Partager**, puis **Sur l'écran d'accueil**.

L'icône « porte verte sur papier peint jaune » apparaît sur ton écran d'accueil.

## Jouer sans internet

1. Ouvre le jeu **une fois avec internet** : il enregistre tout ce dont il a besoin (le moteur 3D compris).
2. Mets ton téléphone en **mode avion** et ouvre l'application depuis l'icône : le jeu se lance.
3. Ta progression (le niveau atteint) est sauvegardée sur le téléphone.

## À savoir

- Le mode **2 joueurs** a besoin d'internet : seul le jeu solo marche hors ligne.
- Si tu modifies le jeu et le remets sur GitHub, ouvre `sw.js` et change `br-v1` en `br-v2` (puis `br-v3`…) pour que les téléphones prennent la nouvelle version.
- Le jeu a besoin du moteur 3D three.js. Il le télécharge tout seul la première fois. Pour ne pas dépendre d'internet du tout, tu peux télécharger `three.min.js` (version r128, depuis cdnjs.cloudflare.com) et l'ajouter dans le dépôt, à côté de `index.html` : le jeu l'utilisera en priorité.
- Pour l'essayer sur ordinateur : mets le jeu en ligne comme ci-dessus. Un double-clic sur `index.html` ne suffit pas à activer le mode hors ligne, car les navigateurs bloquent ça sur un fichier local.

Inspiré du Backrooms Wiki (licence CC BY-SA 3.0) et de la creepypasta originale.
